import os
import sys
import io
import time
import re
import json
import sqlite3
import urllib.request
import multiprocessing
import subprocess
import socket
from datetime import datetime
import asyncio
import traceback
import gradio as gr
from ddgs import DDGS

# Тяжёлая CrewAI-логика вынесена в agent_worker.py.
# Дочерний процесс (spawn) импортирует только лёгкий модуль, а не весь Gradio UI.
from agent_worker import worker_crew_execution, force_save_code, slugify_filename

BASE_DIR = os.environ.get("AI_MULTI_AGENT_DIR", os.path.expanduser("~/ai-multi-agent"))
WORKING_DIR = os.path.join(BASE_DIR, "output")
DB_PATH = os.path.join(BASE_DIR, "chats.db")
os.makedirs(WORKING_DIR, exist_ok=True)

CURRENT_CREW_PROCESS = None

# ====================== БАЗА ДАННЫХ И ПАМЯТЬ АГЕНТОВ ======================
def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id TEXT PRIMARY KEY,
                title TEXT,
                updated_at TEXT,
                history_json TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS agent_notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT,
                content TEXT,
                tags TEXT,
                created_at TEXT
            )
        """)
        conn.commit()

init_db()

def get_conversations_list():
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, title FROM conversations ORDER BY updated_at DESC LIMIT 30")
        return cursor.fetchall()

def save_chat_to_db(chat_id: str, title: str, history: list):
    with sqlite3.connect(DB_PATH) as conn:
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        clean_title = title.replace("\n", " ").strip()[:35]
        conn.execute("""
            INSERT INTO conversations (id, title, updated_at, history_json)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                title=excluded.title,
                updated_at=excluded.updated_at,
                history_json=excluded.history_json
        """, (chat_id, clean_title, now_str, json.dumps(history, ensure_ascii=False)))
        conn.commit()

def load_chat_by_id(chat_id: str) -> list:
    if not chat_id or chat_id == "default":
        return []
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT history_json FROM conversations WHERE id = ?", (chat_id,))
        row = cursor.fetchone()
        if row and row[0]:
            try:
                return json.loads(row[0])
            except Exception:
                return []
    return []

def delete_chat_db(chat_id: str):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("DELETE FROM conversations WHERE id = ?", (chat_id,))
        conn.commit()

def rename_chat_db(chat_id: str, new_title: str):
    clean_title = new_title.replace("\n", " ").strip()[:35]
    if clean_title:
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute("UPDATE conversations SET title = ? WHERE id = ?", (clean_title, chat_id))
            conn.commit()

def save_note_direct(title: str, content: str, tags: str = "security"):
    try:
        with sqlite3.connect(DB_PATH) as conn:
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            conn.execute(
                "INSERT INTO agent_notes (title, content, tags, created_at) VALUES (?, ?, ?, ?)",
                (title[:80], content, tags[:50], now_str)
            )
            conn.commit()
    except Exception:
        pass

# ====================== МОДЕЛИ OLLAMA ======================
def get_installed_ollama_models():
    try:
        req = urllib.request.Request("http://localhost:11434/api/tags")
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            models = [m["name"] for m in data.get("models", [])]
            if models:
                return sorted(models)
    except Exception:
        pass
    return ["llama3.1-8b-abliterated:latest", "Qwen2.5-Coder:7B", "Llama-3-8B-Instruct-Cybersecurity:Q4_K_M"]

INSTALLED_MODELS = get_installed_ollama_models()

def abort_ollama_hardware():
    """Выгружает только реально загруженные модели (через /api/ps), а не все 16 установленных."""
    try:
        req = urllib.request.Request("http://localhost:11434/api/ps")
        with urllib.request.urlopen(req, timeout=2) as resp:
            loaded = json.loads(resp.read().decode("utf-8")).get("models", [])
        for m in loaded:
            name = m.get("name") or m.get("model")
            if not name:
                continue
            payload = json.dumps({"model": name, "keep_alive": 0}).encode("utf-8")
            req = urllib.request.Request(
                "http://localhost:11434/api/generate",
                data=payload,
                headers={"Content-Type": "application/json"}
            )
            urllib.request.urlopen(req, timeout=2)
    except Exception:
        pass

def terminate_active_agent_process():
    global CURRENT_CREW_PROCESS
    if CURRENT_CREW_PROCESS is not None and CURRENT_CREW_PROCESS.is_alive():
        print("\n[CYBER_KILL] Немедленное прерывание процесса агентов...")
        CURRENT_CREW_PROCESS.terminate()
        time.sleep(0.1)
        if CURRENT_CREW_PROCESS.is_alive():
            CURRENT_CREW_PROCESS.kill()
        CURRENT_CREW_PROCESS.join(timeout=0.5)
        CURRENT_CREW_PROCESS = None
    abort_ollama_hardware()

# ====================== МЕЖПРОЦЕССНЫЙ ЛОГГЕР ТЕРМИНАЛА ======================
class QueueStreamLogger(io.StringIO):
    def __init__(self, queue):
        super().__init__()
        self.queue = queue
        self.terminal = sys.__stdout__

    def write(self, message):
        self.terminal.write(message)
        self.terminal.flush()
        if message:
            clean_msg = message
            for code in ["\033[95m", "\033[92m", "\033[93m", "\033[91m", "\033[0m", "\033[1m"]:
                clean_msg = clean_msg.replace(code, "")
            self.queue.put(clean_msg)

    def flush(self):
        self.terminal.flush()

# ====================== ПОИСК В СЕТИ ======================
SESSION_SOURCES = []

def clean_search_query(raw_query: str) -> str:
    q = raw_query.lower()
    for sp in ["выдай отчет про", "напиши отчет", "найди мне", "что слышно про", "последние новости", "и.т.д.", "пожалуйста"]:
        q = q.replace(sp, "")
    return " ".join(q.split()) if len(q.split()) > 1 else raw_query

def fetch_web_sources(query: str, max_results: int = 7) -> tuple[str, list]:
    global SESSION_SOURCES
    SESSION_SOURCES = []
    clean_q = clean_search_query(query)
    print(f"\n[CYBER_NET_SCAN] Сканирование сети: '{clean_q}'...")

    results = []
    try:
        results = list(DDGS().news(clean_q, max_results=max_results))
    except Exception:
        pass

    if not results:
        try:
            results = list(DDGS().text(f"{clean_q} новости", max_results=max_results))
        except Exception:
            pass

    formatted_context = []
    for idx, r in enumerate(results, 1):
        title = r.get("title", f"Источник {idx}").replace('"', "'")
        body = (r.get("body", "") or r.get("snippet", "")).replace('"', "'")
        href = r.get("url", "") or r.get("href", "#")
        if not body or len(body.strip()) < 30:
            continue

        SESSION_SOURCES.append({"id": idx, "title": title, "snippet": body[:250], "url": href})
        formatted_context.append(f"УЗЕЛ ДАННЫХ [{idx}]:\nЗаголовок: {title}\nФакты: {body}\nURL: {href}")

    return "\n\n".join(formatted_context), SESSION_SOURCES

def clean_duplicated_tail_citations(text: str) -> str:
    cleaned = re.sub(r'(\n|\s)*(Примечания|Источники|Ссылки|Литература)?(\s*\[\d+\][\s\S]*)$', '', text.strip(), flags=re.IGNORECASE)
    cleaned = re.sub(r'(\s*\[\d+\]\s*)+$', '', cleaned.strip())
    return cleaned

def format_interactive_markdown_sources(text: str) -> str:
    global SESSION_SOURCES
    if not SESSION_SOURCES:
        return text

    clean_text = clean_duplicated_tail_citations(text)

    def replace_citation(match):
        idx_str = match.group(1)
        try:
            idx = int(idx_str)
            src = next((s for s in SESSION_SOURCES if s["id"] == idx), None)
            if src:
                tooltip = f"{src['title']} — {src['snippet'][:180]}"
                return f' [[{idx}]]({src["url"]} "{tooltip}")'
        except Exception:
            pass
        return match.group(0)

    return re.sub(r'\[(\d+)\]', replace_citation, clean_text)

def clean_code_output(raw_text: str) -> str:
    cleaned = raw_text.strip()
    if cleaned.startswith("{") and "report" in cleaned:
        try:
            parsed = json.loads(cleaned)
            rep = parsed.get("report", {})
            lines = [f"# {rep.get('title', 'Отчет безопасности')}\n"]
            for sec in rep.get("sections", []):
                lines.append(f"### {sec.get('section_title', '')}\n{sec.get('content', '')}\n")
            for issue in rep.get("security_issues", []):
                lines.append(f"- **{issue.get('issue')}**: {issue.get('description')} (`{issue.get('location')}`)")
            return "\n".join(lines)
        except Exception:
            pass

    cleaned = re.sub(r'```json\s*\{\s*"name":\s*".*?"\s*\}\s*```', '', cleaned, flags=re.DOTALL)
    cleaned = re.sub(
        r'\{\s*"name":\s*"(explore_project_structure|run_pytest_suite|cyber_environment_doctor)".*?\}',
        '', cleaned, flags=re.DOTALL
    )
    return cleaned.strip()


def detect_local_file_content(user_request: str) -> tuple[str, str]:
    req = user_request.lower()
    for root, _, files in os.walk(WORKING_DIR):
        for f in files:
            if f.lower() in req and not f.startswith("test_"):
                target_path = os.path.join(root, f)
                try:
                    with open(target_path, "r", encoding="utf-8", errors="ignore") as fp:
                        lines = fp.readlines()
                    return f, "".join(lines[:150])
                except Exception:
                    pass
    # Ищем любой .py без test_
    for root, _, files in os.walk(WORKING_DIR):
        for f in sorted(files):
            if f.endswith(".py") and not f.startswith("test_"):
                target_path = os.path.join(root, f)
                try:
                    with open(target_path, "r", encoding="utf-8", errors="ignore") as fp:
                        content = fp.read()
                    return f, content[:3000]
                except Exception:
                    pass
    return "", ""


# ====================== РЕНДЕР САЙДБАРА ======================
def render_sidebar_html(active_chat_id="default"):
    convs = get_conversations_list()
    if not convs:
        return "<div style='color: #4b5563; font-size: 13px; padding: 16px; text-align: center;'>[ ПУСТАЯ БАЗА ]</div>"

    items_html = []
    for cid, title in convs:
        is_active = "active" if cid == active_chat_id else ""
        escaped_title = title.replace("'", "&#39;").replace('"', "&quot;")
        item = f"""
        <div class="chat-item {is_active}" data-id="{cid}">
            <span class="chat-title" onclick="appSelectChat('{cid}')" title="{escaped_title}">
                <span class="cyber-dot"></span>{escaped_title}
            </span>
            <button type="button" class="chat-menu-btn" onclick="appToggleMenu(event, '{cid}')">⋮</button>
            <div id="menu-{cid}" class="chat-dropdown-menu">
                <div class="chat-dropdown-item" onclick="appOpenRenameModal(event, '{cid}', '{escaped_title}')">
                    <span>✏️</span> Переименовать
                </div>
                <div class="chat-dropdown-item delete-item" onclick="appDeleteChat(event, '{cid}')">
                    <span>🗑️</span> Удалить
                </div>
            </div>
        </div>
        """
        items_html.append(item)
    return "".join(items_html)

# ====================== ОСНОВНОЙ КОНВЕЙЕР ОБРАБОТКИ ======================
async def process_chat(user_request, history, current_chat_id, user_mode_choice, general_m, coder_m, cyber_m, patch_m, qa_m):
    global SESSION_SOURCES, CURRENT_CREW_PROCESS
    if not user_request or not user_request.strip():
        yield history, "", "", gr.update(), current_chat_id, gr.update(visible=True), gr.update(visible=False)
        return

    start_time = time.perf_counter()
    user_time_str = datetime.now().strftime("%d.%m.%Y %H:%M:%S")

    formatted_user_msg = f"{user_request}\n\n<div style='font-size: 11px; opacity: 0.4; margin-top: 4px; font-family: monospace;'>⏱ {user_time_str}</div>"

    if history is None:
        history = []

    req = user_request.lower()
    target_filename, target_file_code = detect_local_file_content(user_request)

    if user_mode_choice == "🧪 Генерация тестов (pytest)":
        mode_str = "test_gen"
        display_mode = "Автогенерация тестов безопасности (pytest) 🧪"
    elif user_mode_choice == "🛡️ Только аудит безопасности":
        mode_str = "sec_only"
        display_mode = "Аудит Инфобезопасности 🛡️"
    elif user_mode_choice == "💻 Только код":
        mode_str = "code_only"
        display_mode = "Кибер-Разработка 💻"
    elif user_mode_choice == "🧠 Полный цикл (Dev + Sec + Patch + QA)":
        mode_str = "full_dev"
        display_mode = "Полный цикл: Архитектор 🧠 -> Кодер 💻 -> Аудит 🛡️ -> Патч 🛠️ -> QA Тесты 🧪"
    elif user_mode_choice == "🔍 Поиск в сети":
        mode_str = "search"
        display_mode = "Глубокое Сканирование Сети 🔍"
    else:
        is_test_intent = any(k in req for k in ["тест", "pytest", "test", "проверк"])
        is_create_intent = any(k in req for k in ["создай", "спроектируй", "разработай", "новый микросервис", "напиши микросервис"])
        is_sec_intent = any(k in req for k in ["безопасн", "уязвим", "пентест", "аудит", "cve", "защит"])

        if is_test_intent and not is_create_intent:
            mode_str = "test_gen"
            display_mode = "Автогенерация тестов безопасности (pytest) 🧪"
        elif is_create_intent and (is_sec_intent or is_test_intent):
            mode_str = "full_dev"
            display_mode = "Полный цикл: Архитектор 🧠 -> Кодер 💻 -> Аудит 🛡️ -> Патч 🛠️ -> QA Тесты 🧪"
        elif is_sec_intent:
            mode_str = "sec_only"
            display_mode = "Аудит Инфобезопасности 🛡️"
        elif is_create_intent or "код" in req:
            mode_str = "code_only"
            display_mode = "Кибер-Разработка 💻"
        else:
            mode_str = "search"
            display_mode = "Глубокое Сканирование Сети 🔍"

    short_q = user_request[:35] + ("..." if len(user_request) > 35 else "")
    thinking_html = (
        f"<div class='thinking-container'>"
        f"<div class='cyber-scanner'></div>"
        f"<span>[СИСТЕМА] Запуск: «{short_q}» [{display_mode}]</span>"
        f"<div class='thinking-dots'><span></span><span></span><span></span></div>"
        f"</div>"
    )

    history.append({"role": "user", "content": formatted_user_msg})
    history.append({"role": "assistant", "content": thinking_html})

    SESSION_SOURCES = []

    if not current_chat_id or current_chat_id == "default":
        current_chat_id = f"chat_{int(time.time())}"

    yield history, "", f"[CYBERPUNK PIPELINE INIT] Режим: '{display_mode}'...\n", gr.update(value=render_sidebar_html(current_chat_id)), current_chat_id, gr.update(visible=False), gr.update(visible=True)

    saved_file_path = ""
    saved_test_path = ""
    raw_web_context = ""

    if mode_str == "search":
        raw_web_context, _ = await asyncio.to_thread(fetch_web_sources, user_request, 7)

    result_queue = multiprocessing.Queue()
    log_queue = multiprocessing.Queue()
    live_logs = []

    CURRENT_CREW_PROCESS = multiprocessing.Process(
        target=worker_crew_execution,
        args=(mode_str, user_request, raw_web_context, target_filename, target_file_code, general_m, coder_m, cyber_m, patch_m, qa_m, result_queue, log_queue)
    )
    CURRENT_CREW_PROCESS.start()

    try:
        while CURRENT_CREW_PROCESS.is_alive():
            while not log_queue.empty():
                try:
                    live_logs.append(log_queue.get_nowait())
                except Exception:
                    break

            terminal_str = "".join(live_logs[-80:])
            yield history, "", terminal_str, gr.update(value=render_sidebar_html(current_chat_id)), current_chat_id, gr.update(visible=False), gr.update(visible=True)
            await asyncio.sleep(0.3)

        while not log_queue.empty():
            try:
                live_logs.append(log_queue.get_nowait())
            except Exception:
                break
        terminal_str = "".join(live_logs[-80:])

        if not result_queue.empty():
            res_data = result_queue.get()
        else:
            res_data = {"status": "error", "error": "Поток был аварийно остановлен."}

        if res_data["status"] == "error":
            raise Exception(res_data.get("error", "Неизвестная ошибка"))

        service_filename = res_data.get("service_filename") or f"{slugify_filename(user_request)}.py"
        test_filename = res_data.get("test_filename") or f"test_{slugify_filename(user_request)}.py"

        if mode_str == "full_dev":
            cleaned_coder_code = clean_code_output(res_data.get("code", ""))
            cyber_report = clean_code_output(res_data.get("sec", ""))
            tests_code = clean_code_output(res_data.get("tests", ""))

            if cleaned_coder_code:
                saved_file_path = force_save_code(cleaned_coder_code, service_filename)
            if tests_code:
                saved_test_path = force_save_code(tests_code, test_filename)

            final_content = (
                f"### 🛠️ Безопасный код после патчинга (FastAPI + SQLite)\n\n{cleaned_coder_code}\n\n---\n"
                f"### 🛡️ Аудит информационной безопасности\n\n{cyber_report}\n\n---\n"
                f"### 🧪 Автоматические тесты (pytest)\n\n{tests_code}"
            )

        elif mode_str == "test_gen":
            tests_code = clean_code_output(res_data.get("tests", ""))
            if tests_code:
                saved_test_path = force_save_code(tests_code, test_filename)
            final_content = f"### 🧪 Автономный набор тестов безопасности pytest\n\n{tests_code}"

        elif mode_str == "search":
            formatted_report = format_interactive_markdown_sources(res_data.get("raw", ""))
            sources_list_md = ""
            if SESSION_SOURCES:
                items = "\n".join([f"- [{s['id']}] [{s['title']}]({s['url']})" for s in SESSION_SOURCES])
                sources_list_md = f"<details open class='cyber-details'><summary><b>🌐 Подтвержденные источники данных ({len(SESSION_SOURCES)})</b></summary>\n\n{items}\n</details>\n\n---\n\n"
            final_content = sources_list_md + formatted_report
        else:
            final_content = clean_code_output(res_data.get("raw", ""))

        elapsed_seconds = round(time.perf_counter() - start_time, 1)
        bot_time_str = datetime.now().strftime("%d.%m.%Y %H:%M:%S")

        save_badge = f"<span>💾 <b>Сервис:</b> <code>{saved_file_path}</code></span>" if saved_file_path else ""
        test_badge = f"<span>🧪 <b>Файл тестов:</b> <code>{saved_test_path}</code></span>" if saved_test_path else ""
        memory_badge = f"<span>🧠 <b>Заметка сохранена:</b> <code>chats.db -> agent_notes</code></span>" if mode_str in ["sec_only", "full_dev"] else ""

        footer_badge = (
            f"\n\n---\n"
            f"<div class='cyber-footer-badge'>"
            f"<span>⚡ <b>Инференс:</b> {elapsed_seconds}s</span>"
            f"<span>📅 <b>Ответ:</b> {bot_time_str}</span>"
            f"{save_badge}"
            f"{test_badge}"
            f"{memory_badge}"
            f"</div>"
        )

        final_answer = f"**Режим:** {display_mode}\n\n{final_content}{footer_badge}"
        history[-1] = {"role": "assistant", "content": final_answer}

        chat_title = user_request.replace("\n", " ").strip()[:35]
        save_chat_to_db(current_chat_id, chat_title, history)

        yield history, "", terminal_str, gr.update(value=render_sidebar_html(current_chat_id)), current_chat_id, gr.update(visible=True), gr.update(visible=False)

    except asyncio.CancelledError:
        terminate_active_agent_process()
        elapsed_seconds = round(time.perf_counter() - start_time, 1)
        cancel_msg = f"🛑 *Процесс прерван оператором ({elapsed_seconds}s)*"
        if history and history[-1]["role"] == "assistant":
            history[-1]["content"] = cancel_msg
        yield history, "", "".join(live_logs[-80:]), gr.update(value=render_sidebar_html(current_chat_id)), current_chat_id, gr.update(visible=True), gr.update(visible=False)

    except Exception as e:
        terminate_active_agent_process()
        elapsed_seconds = round(time.perf_counter() - start_time, 1)
        err_msg = f"**[СБОЙ НЕЙРОСЕТИ]:**\n```\n{str(e)}\n\n{traceback.format_exc()}\n```"
        history[-1] = {"role": "assistant", "content": err_msg}
        yield history, "", "".join(live_logs[-80:]), gr.update(value=render_sidebar_html(current_chat_id)), current_chat_id, gr.update(visible=True), gr.update(visible=False)

    finally:
        CURRENT_CREW_PROCESS = None

def handle_user_stop_click():
    terminate_active_agent_process()
    return gr.update(visible=True), gr.update(visible=False)

# ====================== ДИСПЕТЧЕР САЙДБАРА ======================
def handle_sidebar_action(action_payload, current_id):
    if not action_payload or not action_payload.strip():
        return gr.update(), current_id, gr.update()

    try:
        data = json.loads(action_payload)
        act = data.get("action")
        cid = data.get("id")

        if act == "select":
            hist = load_chat_by_id(cid)
            return hist, cid, gr.update(value=render_sidebar_html(cid))

        elif act == "delete":
            delete_chat_db(cid)
            convs = get_conversations_list()
            new_active = convs[0][0] if convs else "default"
            hist = load_chat_by_id(new_active)
            return hist, new_active, gr.update(value=render_sidebar_html(new_active))

        elif act == "rename":
            new_title = data.get("title", "")
            rename_chat_db(cid, new_title)
            return gr.update(), current_id, gr.update(value=render_sidebar_html(current_id))

        elif act == "new":
            new_id = f"chat_{int(time.time())}"
            return [], new_id, gr.update(value=render_sidebar_html(new_id))

    except Exception as ex:
        print(f"[ERR_DISPATCHER] {ex}")

    return gr.update(), current_id, gr.update()

# ====================== СТИЛИ КИБЕРПАНК GROK / GEMINI ======================
custom_css = """
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;700&family=Rajdhani:wght@500;600;700&display=swap');

:root {
    --cyber-bg: #07090e;
    --cyber-panel: #0d1017;
    --cyber-border: #1a2233;
    --cyber-cyan: #00f0ff;
    --cyber-neon: #00ffcc;
    --cyber-pink: #ff0055;
    --cyber-blue: #2563eb;
    --cyber-text: #e2e8f0;
}

body, .gradio-container {
    background-color: var(--cyber-bg) !important;
    color: var(--cyber-text) !important;
    font-family: 'JetBrains Mono', -apple-system, sans-serif !important;
}

#sidebar-col {
    background-color: var(--cyber-panel) !important;
    border-right: 1px solid var(--cyber-border) !important;
    padding: 16px 14px !important;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
    overflow: hidden !important;
    box-shadow: 2px 0 15px rgba(0, 0, 0, 0.5) !important;
}

#sidebar-col.sidebar-collapsed {
    width: 0 !important;
    min-width: 0 !important;
    max-width: 0 !important;
    padding: 0 !important;
    margin: 0 !important;
    opacity: 0 !important;
    border-right: none !important;
    pointer-events: none !important;
}

.sidebar-toggle-btn {
    background: #131722;
    border: 1px solid var(--cyber-border);
    color: var(--cyber-cyan);
    padding: 6px 10px;
    border-radius: 8px;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.2s ease;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-weight: 600;
}
.sidebar-toggle-btn:hover {
    border-color: var(--cyber-cyan);
    box-shadow: 0 0 10px rgba(0, 240, 255, 0.3);
    color: #ffffff;
}

.hidden-bridge {
    position: fixed !important;
    top: -9999px !important;
    left: -9999px !important;
    width: 1px !important;
    height: 1px !important;
    opacity: 0 !important;
    pointer-events: none !important;
}

.chat-item {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 9px 12px;
    margin-bottom: 4px;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.15s ease;
    color: #94a3b8;
    font-size: 13px;
    border: 1px solid transparent;
}
.chat-item:hover {
    background-color: #161b26;
    color: #ffffff;
    border-color: rgba(0, 240, 255, 0.2);
}
.chat-item.active {
    background-color: #121d2d;
    color: var(--cyber-cyan);
    border-color: var(--cyber-cyan);
    box-shadow: inset 0 0 10px rgba(0, 240, 255, 0.1);
}

.cyber-dot {
    display: inline-block;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background-color: var(--cyber-cyan);
    margin-right: 8px;
    box-shadow: 0 0 6px var(--cyber-cyan);
}

.chat-title {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    width: 170px;
    display: flex;
    align-items: center;
}

.chat-menu-btn {
    opacity: 0;
    background: transparent;
    border: none;
    color: #94a3b8;
    cursor: pointer;
    font-size: 18px;
    line-height: 1;
    padding: 2px 6px;
    border-radius: 4px;
    transition: all 0.15s ease;
}
.chat-item:hover .chat-menu-btn, .chat-item.active .chat-menu-btn {
    opacity: 1;
}
.chat-menu-btn:hover {
    color: #ffffff;
    background-color: #263147;
}

.chat-dropdown-menu {
    display: none;
    position: absolute;
    right: 8px;
    top: 36px;
    background-color: #10141f;
    border: 1px solid var(--cyber-cyan);
    border-radius: 8px;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.8), 0 0 15px rgba(0, 240, 255, 0.15);
    z-index: 1000;
    min-width: 150px;
    padding: 6px;
}
.chat-dropdown-item {
    padding: 8px 12px;
    font-size: 12px;
    color: #cbd5e1;
    border-radius: 6px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.15s ease;
}
.chat-dropdown-item:hover {
    background-color: #1a2234;
    color: var(--cyber-cyan);
}
.chat-dropdown-item.delete-item:hover {
    background-color: #3b111e;
    color: #ff3366;
}

.thinking-container {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    color: var(--cyber-cyan);
    font-size: 13.5px;
    padding: 8px 0;
    letter-spacing: 0.5px;
}
.cyber-scanner {
    width: 12px;
    height: 12px;
    border: 2px solid var(--cyber-cyan);
    border-top-color: transparent;
    border-radius: 50%;
    animation: cyber-spin 0.8s linear infinite;
}
@keyframes cyber-spin {
    to { transform: rotate(360deg); }
}
.thinking-dots {
    display: inline-flex;
    gap: 5px;
}
.thinking-dots span {
    width: 6px;
    height: 6px;
    background-color: var(--cyber-cyan);
    border-radius: 50%;
    box-shadow: 0 0 8px var(--cyber-cyan);
    animation: pulse-dot 1.4s infinite ease-in-out both;
}
.thinking-dots span:nth-child(1) { animation-delay: -0.32s; }
.thinking-dots span:nth-child(2) { animation-delay: -0.16s; }
.thinking-dots span:nth-child(3) { animation-delay: 0s; }

@keyframes pulse-dot {
    0%, 80%, 100% { transform: scale(0.2); opacity: 0.2; }
    40% { transform: scale(1.0); opacity: 1; }
}

#custom-rename-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(4, 6, 10, 0.85);
    backdrop-filter: blur(8px);
    z-index: 99999;
    align-items: center;
    justify-content: center;
}
.modal-card {
    background-color: #0d111a;
    border: 1px solid var(--cyber-cyan);
    border-radius: 12px;
    width: 90%;
    max-width: 400px;
    padding: 24px;
    box-shadow: 0 0 35px rgba(0, 240, 255, 0.2);
}
.modal-card h3 {
    margin: 0 0 16px 0;
    font-size: 16px;
    color: var(--cyber-cyan);
    text-transform: uppercase;
    letter-spacing: 1px;
}
.modal-card input {
    width: 100%;
    background-color: #06080d;
    border: 1px solid var(--cyber-border);
    border-radius: 8px;
    color: #ffffff;
    font-size: 14px;
    padding: 12px 14px;
    margin-bottom: 20px;
    outline: none;
    box-sizing: border-box;
}
.modal-card input:focus {
    border-color: var(--cyber-cyan);
    box-shadow: 0 0 12px rgba(0, 240, 255, 0.3);
}
.modal-actions {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
}
.modal-btn {
    padding: 9px 18px;
    border-radius: 8px;
    font-size: 13px;
    cursor: pointer;
    border: none;
    font-weight: 600;
}
.modal-btn-cancel {
    background-color: #1e2638;
    color: #94a3b8;
}
.modal-btn-save {
    background-color: var(--cyber-cyan);
    color: #000000;
    font-weight: 700;
    box-shadow: 0 0 15px rgba(0, 240, 255, 0.4);
}

#chat-box {
    background-color: transparent !important;
    border: none !important;
}

#input-container {
    background-color: #0d111a !important;
    border: 1px solid var(--cyber-border) !important;
    border-radius: 16px !important;
    padding: 8px 12px !important;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.6) !important;
    display: flex !important;
    align-items: center !important;
    min-height: 58px !important;
    transition: all 0.2s ease !important;
}
#input-container:focus-within {
    border-color: var(--cyber-cyan) !important;
    box-shadow: 0 0 20px rgba(0, 240, 255, 0.25) !important;
}

#user-input {
    flex-grow: 1 !important;
    margin: 0 !important;
    padding: 0 !important;
}
#user-input textarea {
    background: transparent !important;
    border: none !important;
    color: #ffffff !important;
    font-size: 15px !important;
    box-shadow: none !important;
    height: 44px !important;
    min-height: 44px !important;
    padding: 10px 12px !important;
    line-height: 24px !important;
    box-sizing: border-box !important;
    resize: none !important;
}

#submit-btn {
    background: linear-gradient(135deg, #00f0ff 0%, #0088ff 100%) !important;
    color: #000000 !important;
    border-radius: 12px !important;
    font-weight: 700 !important;
    border: none !important;
    height: 46px !important;
    min-height: 46px !important;
    min-width: 135px !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    margin: 0 0 0 8px !important;
    box-shadow: 0 0 15px rgba(0, 240, 255, 0.35) !important;
    transition: all 0.2s ease !important;
}
#submit-btn:hover {
    box-shadow: 0 0 25px rgba(0, 240, 255, 0.6) !important;
    transform: translateY(-1px);
}

#stop-btn {
    background: linear-gradient(135deg, #ff0055 0%, #aa0033 100%) !important;
    color: #ffffff !important;
    border-radius: 12px !important;
    font-weight: 700 !important;
    border: none !important;
    height: 46px !important;
    min-height: 46px !important;
    min-width: 135px !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    margin: 0 0 0 8px !important;
    box-shadow: 0 0 20px rgba(255, 0, 85, 0.4) !important;
}

#terminal-log textarea {
    font-family: 'JetBrains Mono', monospace !important;
    font-size: 11px !important;
    background-color: #05070a !important;
    color: #00f0ff !important;
    border: 1px solid var(--cyber-border) !important;
    border-radius: 8px !important;
}

.cyber-details {
    background-color: #0b0f17;
    border: 1px solid var(--cyber-border);
    border-radius: 10px;
    padding: 10px 14px;
    margin-bottom: 14px;
}
.cyber-details summary {
    cursor: pointer;
    color: var(--cyber-cyan);
    font-size: 13px;
    font-weight: 600;
}

.cyber-footer-badge {
    display: flex;
    flex-wrap: wrap;
    gap: 16px;
    font-size: 11px;
    color: #94a3b8;
    margin-top: 10px;
    border-top: 1px solid var(--cyber-border);
    padding-top: 8px;
}
"""

# ====================== JAVASCRIPT ======================
custom_js = """
<script>
let currentRenamingId = null;

function toggleCyberSidebar() {
    const sb = document.getElementById('sidebar-col');
    const btn = document.getElementById('toggle-sidebar-btn');
    if (sb) {
        sb.classList.toggle('sidebar-collapsed');
        if (btn) {
            btn.innerHTML = sb.classList.contains('sidebar-collapsed') ? '⚡ Развернуть [ ☰ ]' : '[ ☰ ] Свернуть панель';
        }
    }
}

function appToggleMenu(e, id) {
    e.stopPropagation();
    document.querySelectorAll('.chat-dropdown-menu').forEach(m => {
        if (m.id !== 'menu-' + id) m.style.display = 'none';
    });
    const m = document.getElementById('menu-' + id);
    if (m) {
        m.style.display = (m.style.display === 'block') ? 'none' : 'block';
    }
}

document.addEventListener('click', function() {
    document.querySelectorAll('.chat-dropdown-menu').forEach(m => m.style.display = 'none');
});

function sendGradioBridgeAction(payload) {
    const bridgeContainer = document.querySelector('#action-bridge-input');
    const bridgeBtn = document.querySelector('#action-bridge-btn');
    if (!bridgeContainer || !bridgeBtn) return;

    const bridgeInput = bridgeContainer.querySelector('textarea') || bridgeContainer.querySelector('input');
    if (bridgeInput) {
        const strVal = JSON.stringify(payload);
        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value")?.set
                          || Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;
        if (nativeSetter) {
            nativeSetter.call(bridgeInput, strVal);
        } else {
            bridgeInput.value = strVal;
        }

        bridgeInput.dispatchEvent(new Event('input', { bubbles: true }));
        bridgeInput.dispatchEvent(new Event('change', { bubbles: true }));

        setTimeout(() => {
            bridgeBtn.click();
        }, 50);
    }
}

function appSelectChat(id) {
    sendGradioBridgeAction({ action: 'select', id: id });
}

function appDeleteChat(e, id) {
    e.stopPropagation();
    sendGradioBridgeAction({ action: 'delete', id: id });
}

function appOpenRenameModal(e, id, title) {
    e.stopPropagation();
    currentRenamingId = id;
    const modal = document.getElementById('custom-rename-modal');
    const inp = document.getElementById('modal-rename-input');
    if (modal && inp) {
        inp.value = title;
        modal.style.display = 'flex';
        setTimeout(() => inp.focus(), 100);
    }
}

function appCloseRenameModal() {
    const modal = document.getElementById('custom-rename-modal');
    if (modal) modal.style.display = 'none';
    currentRenamingId = null;
}

function appSubmitRename() {
    const inp = document.getElementById('modal-rename-input');
    if (inp && currentRenamingId && inp.value.trim()) {
        sendGradioBridgeAction({
            action: 'rename',
            id: currentRenamingId,
            title: inp.value.trim()
        });
        appCloseRenameModal();
    }
}
</script>
"""

# ====================== АВТОИЦЕЛЕНИЕ ОКРУЖЕНИЯ ======================
def auto_heal_startup():
    print("[🛡️ CYBER DOCTOR] Сканирование окружения перед запуском...")
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(('127.0.0.1', 7860)) == 0:
                print("[!] Порт 7860 занят. Попробуйте вручную: fuser -k 7860/tcp  (без sudo, если возможно)")
                # Не убиваем чужие процессы автоматически — это опасно.
    except Exception:
        pass

# ====================== ИНТЕРФЕЙС GRADIO ======================
with gr.Blocks(title="PopCat Cyber-Agent Pro") as demo:
    current_chat_id = gr.State(value="default")

    with gr.Row(elem_classes=["hidden-bridge"]):
        bridge_action_input = gr.Textbox(elem_id="action-bridge-input")
        bridge_action_btn = gr.Button(elem_id="action-bridge-btn")

    gr.HTML(
        """
        <div id="custom-rename-modal">
            <div class="modal-card">
                <h3>Переименовать узел чата</h3>
                <input type="text" id="modal-rename-input" placeholder="Введите имя..." onkeydown="if(event.key==='Enter')appSubmitRename();if(event.key==='Escape')appCloseRenameModal();" />
                <div class="modal-actions">
                    <button type="button" class="modal-btn modal-btn-cancel" onclick="appCloseRenameModal()">Отмена</button>
                    <button type="button" class="modal-btn modal-btn-save" onclick="appSubmitRename()">Сохранить</button>
                </div>
            </div>
        </div>
        """
    )

    with gr.Row():
        with gr.Column(scale=2, min_width=260, elem_id="sidebar-col"):
            gr.HTML(
                """
                <div style='display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px;'>
                    <span style='font-size: 19px; font-weight: 700; color: #00f0ff; letter-spacing: 0.5px;'>⚡ PopCat Pro</span>
                </div>
                """
            )
            new_chat_btn = gr.Button("+ Новый сеанс", variant="secondary", size="sm")

            gr.HTML("<div style='font-size: 11px; text-transform: uppercase; color: #64748b; font-weight: 700; margin: 18px 0 8px 4px; letter-spacing: 1px;'>Архив сессий</div>")

            sidebar_html = gr.HTML(value=render_sidebar_html())

            with gr.Accordion("⚙️ Настройки моделей Ollama", open=False):
                model_general = gr.Dropdown(
                    label="1. Аналитик / Архитектор",
                    choices=INSTALLED_MODELS,
                    value="llama3.1-8b-abliterated:latest" if "llama3.1-8b-abliterated:latest" in INSTALLED_MODELS else INSTALLED_MODELS[0]
                )
                model_coder = gr.Dropdown(
                    label="2. Кодер / Разработчик",
                    choices=INSTALLED_MODELS,
                    value="Qwen2.5-Coder:7B" if "Qwen2.5-Coder:7B" in INSTALLED_MODELS else INSTALLED_MODELS[0]
                )
                model_cyber = gr.Dropdown(
                    label="3. Безопасность (Cyber Expert)",
                    choices=INSTALLED_MODELS,
                    value="Llama-3-8B-Instruct-Cybersecurity:Q4_K_M" if "Llama-3-8B-Instruct-Cybersecurity:Q4_K_M" in INSTALLED_MODELS else (
                        "llama3.1-8b-abliterated:latest" if "llama3.1-8b-abliterated:latest" in INSTALLED_MODELS else INSTALLED_MODELS[0]
                    )
                )
                model_patch = gr.Dropdown(
                    label="4. Инженер исправлений (Patch)",
                    choices=INSTALLED_MODELS,
                    value="Qwen2.5-Coder:7B" if "Qwen2.5-Coder:7B" in INSTALLED_MODELS else INSTALLED_MODELS[0]
                )
                model_qa = gr.Dropdown(
                    label="5. Тестирование / QA (pytest)",
                    choices=INSTALLED_MODELS,
                    value="Qwen2.5-Coder:7B" if "Qwen2.5-Coder:7B" in INSTALLED_MODELS else INSTALLED_MODELS[0]
                )

        with gr.Column(scale=8):
            with gr.Row():
                gr.HTML(
                    """
                    <div style='margin-bottom: 8px;'>
                        <button id='toggle-sidebar-btn' class='sidebar-toggle-btn' onclick='toggleCyberSidebar()'>[ ☰ ] Свернуть панель</button>
                    </div>
                    """
                )

            mode_selector = gr.Dropdown(
                choices=[
                    "⚡ Авто (умный выбор)",
                    "🧪 Генерация тестов (pytest)",
                    "🛡️ Только аудит безопасности",
                    "💻 Только код",
                    "🧠 Полный цикл (Dev + Sec + Patch + QA)",
                    "🔍 Поиск в сети"
                ],
                value="⚡ Авто (умный выбор)",
                label="Режим работы агентов"
            )

            chatbot = gr.Chatbot(height=540, render_markdown=True, sanitize_html=False, elem_id="chat-box")

            with gr.Row(elem_id="input-container", equal_height=True):
                user_input = gr.Textbox(
                    placeholder="Введи задачу: сгенерировать pytest тесты, провести аудит или создать сервис...",
                    show_label=False,
                    scale=9,
                    lines=1,
                    max_lines=5,
                    elem_id="user-input"
                )
                submit_btn = gr.Button("Отправить ↑", scale=1, elem_id="submit-btn", visible=True)
                stop_btn = gr.Button("Остановить ⏹", scale=1, elem_id="stop-btn", visible=False)

            with gr.Accordion("📡 Консоль агентов (Real-Time мысли и Sandbox)", open=False):
                terminal_output = gr.Textbox(
                    label="Служебный терминал",
                    lines=10,
                    interactive=False,
                    elem_id="terminal-log"
                )

    click_event = submit_btn.click(
        process_chat,
        inputs=[user_input, chatbot, current_chat_id, mode_selector, model_general, model_coder, model_cyber, model_patch, model_qa],
        outputs=[chatbot, user_input, terminal_output, sidebar_html, current_chat_id, submit_btn, stop_btn]
    )
    submit_event = user_input.submit(
        process_chat,
        inputs=[user_input, chatbot, current_chat_id, mode_selector, model_general, model_coder, model_cyber, model_patch, model_qa],
        outputs=[chatbot, user_input, terminal_output, sidebar_html, current_chat_id, submit_btn, stop_btn]
    )

    stop_btn.click(
        fn=handle_user_stop_click,
        outputs=[submit_btn, stop_btn],
        cancels=[click_event, submit_event]
    )

    bridge_action_btn.click(
        handle_sidebar_action,
        inputs=[bridge_action_input, current_chat_id],
        outputs=[chatbot, current_chat_id, sidebar_html]
    )

    new_chat_btn.click(
        lambda: ([], f"chat_{int(time.time())}", gr.update(value=render_sidebar_html("default"))),
        outputs=[chatbot, current_chat_id, sidebar_html]
    )

if __name__ == "__main__":
    auto_heal_startup()
    multiprocessing.set_start_method("spawn", force=True)
    # По умолчанию только localhost. Для доступа из сети раскомментируйте auth.
    demo.launch(
        server_name="127.0.0.1",
        server_port=7860,
        show_error=True,
        css=custom_css,
        head=custom_js,
        # auth=("admin", "change_me"),  # раскомментируйте и смените пароль, если нужен доступ с других устройств
    )
