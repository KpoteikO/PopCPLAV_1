"""
Отдельный лёгкий модуль для multiprocessing-воркера CrewAI.
Импортируется только в дочернем процессе — без Gradio, CSS, JS и UI.
"""
import os
import sys
import io
import time
import re
import json
import sqlite3
import urllib.request
import subprocess
import traceback
from datetime import datetime

from crewai import Agent, Task, Crew, Process, LLM
from crewai.tools import tool

# ====================== ПУТИ ======================
BASE_DIR = os.environ.get("AI_MULTI_AGENT_DIR", os.path.expanduser("~/ai-multi-agent"))
WORKING_DIR = os.path.join(BASE_DIR, "output")
DB_PATH = os.path.join(BASE_DIR, "chats.db")
os.makedirs(WORKING_DIR, exist_ok=True)


# ====================== БАЗА ЗАМЕТОК ======================
def save_note_direct(title: str, content: str, tags: str = "security"):
    try:
        with sqlite3.connect(DB_PATH) as conn:
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            conn.execute(
                "INSERT INTO agent_notes (title, content, tags, created_at) VALUES (?, ?, ?, ?)",
                (title[:80], content, tags[:50], now_str)
            )
            conn.commit()
    except Exception:
        pass


# ====================== ЛОГГЕР ======================
class QueueStreamLogger(io.StringIO):
    def __init__(self, queue):
        super().__init__()
        self.queue = queue
        self.terminal = sys.__stdout__

    def write(self, message):
        self.terminal.write(message)
        self.terminal.flush()
        if message:
            clean_msg = message
            for code in ["\033[95m", "\033[92m", "\033[93m", "\033[91m", "\033[0m", "\033[1m"]:
                clean_msg = clean_msg.replace(code, "")
            self.queue.put(clean_msg)

    def flush(self):
        self.terminal.flush()


# ====================== БЕЗОПАСНЫЕ ПУТИ И ИНСТРУМЕНТЫ ======================
def safe_path(file_path: str) -> str:
    base = os.path.abspath(WORKING_DIR)
    target = os.path.abspath(os.path.join(base, file_path))
    if not target.startswith(base):
        raise ValueError("ACCESS DENIED: Попытка выхода за пределы рабочей директории.")
    return target


@tool
def explore_project_structure(dummy: str = "") -> str:
    """Исследует файловую структуру каталога output/. Возвращает дерево всех файлов и их размеры."""
    try:
        tree = []
        base = os.path.abspath(WORKING_DIR)
        for root, dirs, files in os.walk(base):
            level = root.replace(base, '').count(os.sep)
            indent = ' ' * 4 * level
            tree.append(f"{indent}📁 {os.path.basename(root)}/")
            subindent = ' ' * 4 * (level + 1)
            for f in sorted(files):
                fpath = os.path.join(root, f)
                size_kb = round(os.path.getsize(fpath) / 1024, 1)
                tree.append(f"{subindent}📄 {f} ({size_kb} KB)")
        if not tree:
            return "Папка проекта пуста."
        return "\n".join(tree)
    except Exception as e:
        return f"Ошибка сканирования дерева: {str(e)}"


@tool
def run_pytest_suite(test_file: str = "test_auth_service.py") -> str:
    """Запускает набор тестов pytest в песочнице output/ и возвращает результат выполнения."""
    try:
        target = safe_path(test_file)
        if not os.path.exists(target):
            return f"Ошибка: Файл тестов {test_file} не найден."

        cmd = [sys.executable, "-m", "pytest", target, "-v", "--no-header", "-tb=short"]
        proc = subprocess.run(
            cmd,
            cwd=WORKING_DIR,
            capture_output=True,
            text=True,
            timeout=35
        )
        out = proc.stdout if proc.stdout else ""
        err = proc.stderr if proc.stderr else ""
        return f"[PYTEST RETURN CODE: {proc.returncode}]\n{out}\n{err}"
    except subprocess.TimeoutExpired:
        return "Ошибка: Тесты превысили лимит времени выполнения (35 сек)."
    except Exception as e:
        return f"Ошибка запуска тестов: {str(e)}"


@tool
def cyber_environment_doctor(check_type: str = "full") -> str:
    """Диагностирует окружение: проверяет порт 7860, доступность Ollama API и целостность базы данных."""
    import socket
    report = []
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        port_in_use = s.connect_ex(('127.0.0.1', 7860)) == 0
        report.append(f"🔌 Порт 7860 (Gradio): {'Занят (активен)' if port_in_use else 'Свободен'}")

    try:
        req = urllib.request.Request("http://localhost:11434/api/tags")
        with urllib.request.urlopen(req, timeout=2) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            models_count = len(data.get("models", []))
            report.append(f"🟢 Ollama API: Доступен (Моделей найдено: {models_count})")
    except Exception:
        report.append("🔴 Ollama API: Ошибка подключения (сервер не отвечает)")

    db_exists = os.path.exists(DB_PATH)
    output_exists = os.path.exists(WORKING_DIR)
    report.append(f"💾 База данных (chats.db): {'Найдена' if db_exists else 'Отсутствует'}")
    report.append(f"📁 Папка песочницы (output/): {'Готова' if output_exists else 'Создается'}")

    return "\n".join(report)


# ====================== СОХРАНЕНИЕ КОДА ======================
def force_save_code(content: str, filename: str) -> str:
    """Сохраняет код в WORKING_DIR с указанным именем. Возвращает полный путь."""
    try:
        code_to_save = content
        if "```python" in content:
            code_to_save = content.split("```python")[1].split("```")[0].strip()
        elif "```" in content:
            parts = content.split("```")
            if len(parts) >= 2:
                code_to_save = parts[1].strip()
                if code_to_save.startswith("python"):
                    code_to_save = code_to_save[6:].strip()

        # Убираем мусор от tool-calls
        code_to_save = re.sub(
            r'\{\s*"name":\s*"(explore_project_structure|run_pytest_suite|cyber_environment_doctor)".*?\}',
            '', code_to_save, flags=re.DOTALL
        )
        code_to_save = code_to_save.strip()

        file_path = os.path.join(WORKING_DIR, filename)
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(code_to_save)
        return file_path
    except Exception as e:
        print(f"\n[ERROR_DISK_WRITE] {e}")
        return ""


def slugify_filename(text: str, default: str = "service") -> str:
    """Делает безопасное имя файла из запроса пользователя."""
    text = text.lower().strip()
    # Убираем типичные фразы
    for phrase in ["создай", "напиши", "спроектируй", "разработай", "микросервис", "сервис", "fastapi", "код"]:
        text = text.replace(phrase, " ")
    # Оставляем только буквы/цифры
    slug = re.sub(r'[^a-z0-9а-яё]+', '_', text, flags=re.IGNORECASE)
    slug = re.sub(r'_+', '_', slug).strip('_')
    if not slug or len(slug) < 3:
        slug = default
    return slug[:40]


# ====================== ОСНОВНОЙ ВОРКЕР ======================
def worker_crew_execution(
    mode,
    user_request,
    raw_web_context,
    target_filename,
    target_file_code,
    general_m,
    coder_m,
    cyber_m,
    patch_m,
    qa_m,
    result_queue,
    log_queue
):
    sys.stdout = QueueStreamLogger(log_queue)
    try:
        llm_general = LLM(model=f"ollama/{general_m}", base_url="http://localhost:11434", temperature=0.2, max_tokens=3000, timeout=300)
        llm_coder = LLM(model=f"ollama/{coder_m}", base_url="http://localhost:11434", temperature=0.1, max_tokens=3500, timeout=300)
        llm_cyber = LLM(model=f"ollama/{cyber_m}", base_url="http://localhost:11434", temperature=0.1, max_tokens=2500, timeout=300)
        llm_patch = LLM(model=f"ollama/{patch_m}", base_url="http://localhost:11434", temperature=0.1, max_tokens=3500, timeout=300)
        llm_qa = LLM(model=f"ollama/{qa_m}", base_url="http://localhost:11434", temperature=0.1, max_tokens=3500, timeout=300)

        all_tools = [explore_project_structure, run_pytest_suite, cyber_environment_doctor]

        # Динамическое имя файла на основе запроса
        base_slug = slugify_filename(user_request, default="auth_service")
        service_filename = f"{base_slug}.py"
        test_filename = f"test_{base_slug}.py"

        if mode == "test_gen":
            qa_engineer = Agent(
                role="Senior QA Security Test Engineer",
                goal="Написание автономных тестов pytest с TestClient",
                backstory="Ведущий QA-инженер по безопасности API.",
                llm=llm_qa,
                tools=all_tools,
                max_iter=8,
                handle_parsing_errors=True,
                verbose=True
            )
            t = Task(
                description=(
                    f"ЗАДАЧА: Напиши изолированный файл тестов pytest для файла `{target_filename or service_filename}`.\n\n"
                    f"РЕАЛЬНЫЙ КОД СЕРВИСА НА ДИСКЕ:\n```python\n{target_file_code}\n```\n\n"
                    "ОБЯЗАТЕЛЬНЫЕ ПРАВИЛА:\n"
                    "1. Импортируй: `from auth_service import app` (или соответствующий модуль), `from fastapi.testclient import TestClient`.\n"
                    "2. Создай: `client = TestClient(app)`.\n"
                    "3. Напиши позитивные и негативные кейсы (ошибки 401, 400, 403).\n"
                    "4. СТРОГИЙ ЗАПРЕТ: Не пиши код самого сервиса в тестах. Только тесты в одном блоке ```python ... ```."
                ),
                expected_output="Python-код файла тестов pytest в блоке ```python```.",
                agent=qa_engineer
            )
            crew = Crew(agents=[qa_engineer], tasks=[t], process=Process.sequential, verbose=True)
            res = crew.kickoff()
            result_queue.put({"status": "ok", "tests": str(res), "raw": str(res), "service_filename": service_filename, "test_filename": test_filename})

        elif mode == "full_dev":
            architect = Agent(
                role="System Architect",
                goal="Архитектура микросервисов с глубоким исследованием",
                backstory="Кибер-архитектор систем. Следуй принципам Research-инженерии: опирайся на точные факты, проектируй надежные схемы без домыслов.",
                llm=llm_general,
                tools=all_tools,
                verbose=True
            )
            coder = Agent(
                role="Senior Backend Developer",
                goal="Написание начального кода",
                backstory="Senior Python разработчик.",
                llm=llm_coder,
                tools=all_tools,
                max_iter=10,
                handle_parsing_errors=True,
                verbose=True
            )
            security_expert = Agent(
                role="Cybersecurity Specialist",
                goal="Строгий аудит кода по стандарту Code Review (Standards & Spec)",
                backstory="Ведущий AppSec-аудитор. Проводишь двухосевую оценку: проверяешь код на соответствие спецификации (Spec) и стандартам безопасности (Standards). Отвечай строго в формате Markdown, без сырого JSON.",
                llm=llm_cyber,
                tools=all_tools,
                max_iter=8,
                handle_parsing_errors=True,
                verbose=True
            )
            patch_engineer = Agent(
                role="Patch & Remediation Engineer",
                goal="Устранение уязвимостей в коде",
                backstory="Инженер по безопасности и патчингу. Исправляешь замечания аудитора, применяя безопасные практики.",
                llm=llm_patch,
                tools=all_tools,
                max_iter=10,
                handle_parsing_errors=True,
                verbose=True
            )
            qa_engineer = Agent(
                role="QA Test Automation Engineer",
                goal="Написание тестов pytest",
                backstory="Эксперт тестирования API.",
                llm=llm_qa,
                tools=all_tools,
                max_iter=8,
                handle_parsing_errors=True,
                verbose=True
            )

            t1 = Task(description=f"Спроектируй микросервис: {user_request}.", expected_output="План архитектуры.", agent=architect)
            t2 = Task(
                description="Напиши полный код на FastAPI с SQLite и SQLAlchemy. Без сокращений. Выдай ТОЛЬКО код в блоке ```python```.",
                expected_output="Python-код сервиса в блоке ```python```.",
                agent=coder,
                context=[t1]
            )
            t3 = Task(
                description="Проведи аудит безопасности полученного кода. Выяви уязвимости, CWE, OWASP. Строго без JSON!",
                expected_output="Отчет безопасности в Markdown.",
                agent=security_expert,
                context=[t2]
            )
            t4 = Task(
                description="На основе отчета безопасности исправь весь уязвимый код, примени безопасные практики. Выдай итоговый безопасный код в блоке ```python```.",
                expected_output="Исправленный безопасный Python-код в блоке ```python```.",
                agent=patch_engineer,
                context=[t2, t3]
            )
            t5 = Task(
                description="Напиши автономный набор тестов pytest для финального безопасного кода сервиса.",
                expected_output="Python-код файла тестов pytest.",
                agent=qa_engineer,
                context=[t4]
            )

            crew = Crew(
                agents=[architect, coder, security_expert, patch_engineer, qa_engineer],
                tasks=[t1, t2, t3, t4, t5],
                process=Process.sequential,
                verbose=True
            )
            res = crew.kickoff()

            # Сохраняем промежуточный код сразу после t2, чтобы последующие агенты могли его видеть через tools
            code_after_coder = str(t2.output.raw) if hasattr(t2, 'output') and t2.output else ""
            if code_after_coder:
                force_save_code(code_after_coder, service_filename)
                print(f"\n[INTERMEDIATE] Код после coder сохранён: {service_filename}")

            code_out = str(t4.output.raw) if hasattr(t4, 'output') and t4.output else code_after_coder
            sec_out = str(t3.output.raw) if hasattr(t3, 'output') and t3.output else ""
            test_out = str(t5.output.raw) if hasattr(t5, 'output') and t5.output else str(res)

            # Финальное сохранение патченного кода
            if code_out:
                force_save_code(code_out, service_filename)

            result_queue.put({
                "status": "ok",
                "code": code_out,
                "sec": sec_out,
                "tests": test_out,
                "raw": str(res),
                "service_filename": service_filename,
                "test_filename": test_filename
            })

        elif mode == "sec_only":
            security_expert = Agent(
                role="Senior Application Security Engineer",
                goal="Глубокий аудит безопасности исходного кода",
                backstory="Ведущий AppSec-аудитор. СТРОГИЙ ЗАПРЕТ НА JSON! Выдавай ответ исключительно в читаемом формате Markdown на русском языке.",
                llm=llm_cyber,
                tools=all_tools,
                max_iter=8,
                handle_parsing_errors=True,
                verbose=True
            )
            file_context_prompt = f"РЕАЛЬНОЕ СОДЕРЖИМОЕ ФАЙЛА НА ДИСКЕ ({target_filename}):\n```python\n{target_file_code}\n```\n\n" if target_file_code else ""
            t = Task(
                description=(
                    f"ЗАДАЧА: Проведи глубокий аудит безопасности кода по запросу: {user_request}\n\n"
                    f"{file_context_prompt}"
                    "ПРАВИЛА:\n1. Запрещено использовать JSON. Пиши отчет обычным текстом с заголовками Markdown.\n"
                    "2. Выяви уязвимости, CWE, OWASP и дай рекомендации по исправлению."
                ),
                expected_output="Отчет по аудиту безопасности в формате Markdown.",
                agent=security_expert
            )
            crew = Crew(agents=[security_expert], tasks=[t], process=Process.sequential, verbose=True)
            res = crew.kickoff()
            save_note_direct(f"Аудит {target_filename or service_filename}", str(res)[:500], "security_audit")
            result_queue.put({"status": "ok", "raw": str(res), "service_filename": service_filename, "test_filename": test_filename})

        elif mode == "code_only":
            coder = Agent(
                role="Senior Backend Developer",
                goal="Писать чистый код",
                backstory="Senior разработчик.",
                llm=llm_coder,
                tools=all_tools,
                max_iter=10,
                handle_parsing_errors=True,
                verbose=True
            )
            t = Task(
                description=f"Напиши рабочий код: {user_request}. В блоке ```python ... ```.",
                expected_output="Рабочий код.",
                agent=coder
            )
            crew = Crew(agents=[coder], tasks=[t], process=Process.sequential, verbose=True)
            res = crew.kickoff()
            result_queue.put({"status": "ok", "raw": str(res), "service_filename": service_filename, "test_filename": test_filename})

        else:  # search
            researcher = Agent(
                role="Senior Research Analyst",
                goal="Анализ источников",
                backstory="Кибер-аналитик данных.",
                llm=llm_general,
                tools=all_tools,
                verbose=True
            )
            t = Task(
                description=f"ЗАДАЧА: Подготовь подробный отчет по теме: {user_request}\n\n{raw_web_context}",
                expected_output="Отчет со сносками.",
                agent=researcher
            )
            crew = Crew(agents=[researcher], tasks=[t], process=Process.sequential, verbose=True)
            res = crew.kickoff()
            result_queue.put({"status": "ok", "raw": str(res)})

    except Exception as e:
        result_queue.put({"status": "error", "error": str(e), "trace": traceback.format_exc()})
