"""
agent_worker.py
================
Вся "тяжёлая" логика мульти-агентной системы: работа с БД, веб-поиск,
RAG-память на эмбеддингах (nomic-embed-text), инструменты агентов (@tool)
и сам CrewAI-пайплайн (worker_crew_execution).

Почему это отдельный файл, а не часть web_agent.py:
multiprocessing со start_method="spawn" в дочернем процессе заново
ИМПОРТИРУЕТ модуль, в котором объявлена целевая функция. Если бы
worker_crew_execution жила в web_agent.py вместе с gr.Blocks(...),
CSS и JS, каждый(!) запуск задачи в чате пересобирал бы в дочернем
процессе весь Gradio-интерфейс и заново дёргал Ollama API при импорте.
Здесь же дочерний процесс импортирует только то, что ему реально нужно.
"""

import os
import sys
import io
import re
import json
import math
import sqlite3
import subprocess
import socket
import urllib.request
from datetime import datetime

from crewai import Agent, Task, Crew, Process, LLM
from crewai.tools import tool
from ddgs import DDGS

# ====================== ПУТИ И НАСТРОЙКИ ======================
# Раньше путь был жёстко зашит как /home/beluga/ai-multi-agent.
# os.path.expanduser("~/...") резолвится в то же самое для пользователя
# beluga, но теперь переносимо на любую машину/пользователя, и его можно
# переопределить переменной окружения без правки кода.
BASE_DIR = os.environ.get("AGENT_BASE_DIR", os.path.expanduser("~/ai-multi-agent"))
WORKING_DIR = os.path.join(BASE_DIR, "output")
DB_PATH = os.path.join(BASE_DIR, "chats.db")
OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
EMBED_MODEL = os.environ.get("AGENT_EMBED_MODEL", "nomic-embed-text")

os.makedirs(WORKING_DIR, exist_ok=True)

# ====================== БАЗА ДАННЫХ И ПАМЯТЬ АГЕНТОВ ======================
def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id TEXT PRIMARY KEY,
                title TEXT,
                updated_at TEXT,
                history_json TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS agent_notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT,
                content TEXT,
                tags TEXT,
                created_at TEXT,
                embedding TEXT
            )
        """)
        conn.commit()
        # На случай апгрейда со старой БД, где колонки embedding ещё нет.
        cols = [r[1] for r in conn.execute("PRAGMA table_info(agent_notes)").fetchall()]
        if "embedding" not in cols:
            conn.execute("ALTER TABLE agent_notes ADD COLUMN embedding TEXT")
            conn.commit()

init_db()


def get_conversations_list():
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, title FROM conversations ORDER BY updated_at DESC LIMIT 30")
        return cursor.fetchall()


def save_chat_to_db(chat_id: str, title: str, history: list):
    with sqlite3.connect(DB_PATH) as conn:
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        clean_title = title.replace("\n", " ").strip()[:35]
        conn.execute("""
            INSERT INTO conversations (id, title, updated_at, history_json)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                title=excluded.title,
                updated_at=excluded.updated_at,
                history_json=excluded.history_json
        """, (chat_id, clean_title, now_str, json.dumps(history, ensure_ascii=False)))
        conn.commit()


def load_chat_by_id(chat_id: str) -> list:
    if not chat_id or chat_id == "default":
        return []
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT history_json FROM conversations WHERE id = ?", (chat_id,))
        row = cursor.fetchone()
        if row and row[0]:
            try:
                return json.loads(row[0])
            except Exception:
                return []
    return []


def delete_chat_db(chat_id: str):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("DELETE FROM conversations WHERE id = ?", (chat_id,))
        conn.commit()


def rename_chat_db(chat_id: str, new_title: str):
    clean_title = new_title.replace("\n", " ").strip()[:35]
    if clean_title:
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute("UPDATE conversations SET title = ? WHERE id = ?", (clean_title, chat_id))
            conn.commit()


def save_note_direct(title: str, content: str, tags: str = "security", embedding: list = None):
    try:
        with sqlite3.connect(DB_PATH) as conn:
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            emb_json = json.dumps(embedding) if embedding else None
            conn.execute(
                "INSERT INTO agent_notes (title, content, tags, created_at, embedding) VALUES (?, ?, ?, ?, ?)",
                (title[:80], content, tags[:50], now_str, emb_json)
            )
            conn.commit()
    except Exception:
        pass


# ====================== RAG-ПАМЯТЬ (nomic-embed-text) ======================
# У вас уже установлена nomic-embed-text (274 MB, быстрая даже на CPU),
# но раньше она нигде не использовалась. Задействуем её для простого
# векторного поиска по прошлым заметкам аудита — без внешней vector DB,
# просто косинусная близость в SQLite (записей обычно немного, это дёшево).

def get_embedding(text: str, model: str = None) -> list:
    model = model or EMBED_MODEL
    try:
        payload = json.dumps({"model": model, "prompt": text[:2000]}).encode("utf-8")
        req = urllib.request.Request(
            f"{OLLAMA_HOST}/api/embeddings", data=payload,
            headers={"Content-Type": "application/json"}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data.get("embedding", []) or []
    except Exception:
        return []


def cosine_similarity(a: list, b: list) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def save_note_with_embedding(title: str, content: str, tags: str = "security"):
    """Сохраняет заметку и сразу считает для неё эмбеддинг, если Ollama/модель доступны.
    Если эмбеддинг посчитать не удалось — заметка всё равно сохранится (просто без RAG-индекса)."""
    embedding = get_embedding(f"{title}\n{content[:1500]}")
    save_note_direct(title, content, tags, embedding=embedding or None)


def recall_relevant_notes(query: str, top_k: int = 3, min_score: float = 0.55) -> list:
    """Достаёт top_k наиболее релевантных прошлых заметок по косинусной близости эмбеддингов.
    Деградирует тихо (возвращает []), если Ollama/модель эмбеддингов недоступны —
    остальной пайплайн при этом продолжает работать как обычно."""
    q_emb = get_embedding(query)
    if not q_emb:
        return []
    try:
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT title, content, tags, created_at, embedding FROM agent_notes "
                "WHERE embedding IS NOT NULL ORDER BY id DESC LIMIT 300"
            )
            rows = cursor.fetchall()
    except Exception:
        return []

    scored = []
    for title, content, tags, created_at, emb_json in rows:
        try:
            emb = json.loads(emb_json)
        except Exception:
            continue
        score = cosine_similarity(q_emb, emb)
        if score >= min_score:
            scored.append((score, title, content, tags, created_at))

    scored.sort(key=lambda x: x[0], reverse=True)
    return [
        {"score": round(s, 3), "title": t, "content": c, "tags": tg, "date": d}
        for s, t, c, tg, d in scored[:top_k]
    ]


def format_recall_block(notes: list) -> str:
    """Готовит блок для вставки прямо в описание Task — так RAG-контекст
    доходит до модели гарантированно, а не зависит от того, вызовет ли
    маленькая локальная модель инструмент recall_audit_memory сама."""
    if not notes:
        return ""
    lines = ["РЕЛЕВАНТНЫЙ КОНТЕКСТ ИЗ ПРОШЛЫХ АУДИТОВ (используй как справочную информацию, не копируй дословно):"]
    for n in notes:
        lines.append(f"- [{n['date']}, сходство {n['score']}] {n['title']}: {n['content'][:300]}")
    return "\n".join(lines) + "\n\n"


# ====================== МОДЕЛИ OLLAMA ======================
def get_installed_ollama_models() -> list:
    try:
        req = urllib.request.Request(f"{OLLAMA_HOST}/api/tags")
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            models = [m["name"] for m in data.get("models", [])]
            if models:
                return sorted(models)
    except Exception:
        pass
    return ["llama3.1-8b-abliterated:latest", "Qwen2.5-Coder:7B", "Llama-3-8B-Instruct-Cybersecurity:Q4_K_M"]


def get_loaded_ollama_models() -> list:
    """Модели, реально сейчас находящиеся в памяти/VRAM (через /api/ps)."""
    try:
        req = urllib.request.Request(f"{OLLAMA_HOST}/api/ps")
        with urllib.request.urlopen(req, timeout=2) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return [m["name"] for m in data.get("models", [])]
    except Exception:
        return []


def abort_ollama_hardware():
    """Выгружает из VRAM только реально загруженные модели.
    Раньше здесь перебирались ВСЕ установленные модели (включая никогда
    не запускавшиеся в этой сессии), что означало до 16 лишних
    load/unload round-trip'ов к Ollama на каждый Stop/ошибку."""
    for m in get_loaded_ollama_models():
        try:
            payload = json.dumps({"model": m, "keep_alive": 0}).encode("utf-8")
            req = urllib.request.Request(
                f"{OLLAMA_HOST}/api/generate", data=payload,
                headers={"Content-Type": "application/json"}
            )
            urllib.request.urlopen(req, timeout=2)
        except Exception:
            pass


# ====================== МЕЖПРОЦЕССНЫЙ ЛОГГЕР ТЕРМИНАЛА ======================
class QueueStreamLogger(io.StringIO):
    def __init__(self, queue):
        super().__init__()
        self.queue = queue
        self.terminal = sys.__stdout__

    def write(self, message):
        self.terminal.write(message)
        self.terminal.flush()
        if message:
            clean_msg = message
            for code in ["\033[95m", "\033[92m", "\033[93m", "\033[91m", "\033[0m", "\033[1m"]:
                clean_msg = clean_msg.replace(code, "")
            self.queue.put(clean_msg)

    def flush(self):
        self.terminal.flush()


# ====================== ПОИСК В СЕТИ ======================
def clean_search_query(raw_query: str) -> str:
    q = raw_query.lower()
    for sp in ["выдай отчет про", "напиши отчет", "найди мне", "что слышно про", "последние новости", "и.т.д.", "пожалуйста"]:
        q = q.replace(sp, "")
    return " ".join(q.split()) if len(q.split()) > 1 else raw_query


def fetch_web_sources(query: str, max_results: int = 7) -> tuple[str, list]:
    """Возвращает (форматированный_контекст, список_источников).
    Раньше список источников писался в модульный глобал SESSION_SOURCES —
    убрано: единственный вызывающий код (process_chat) держит источники
    в локальной переменной внутри одного запроса, глобал был не нужен
    и создавал гонку между параллельными пользователями/вкладками."""
    clean_q = clean_search_query(query)
    print(f"\n[CYBER_NET_SCAN] Сканирование сети: '{clean_q}'...")

    results = []
    try:
        results = list(DDGS().news(clean_q, max_results=max_results))
    except Exception:
        pass

    if not results:
        try:
            results = list(DDGS().text(f"{clean_q} новости", max_results=max_results))
        except Exception:
            pass

    sources = []
    formatted_context = []
    for idx, r in enumerate(results, 1):
        title = r.get("title", f"Источник {idx}").replace('"', "'")
        body = (r.get("body", "") or r.get("snippet", "")).replace('"', "'")
        href = r.get("url", "") or r.get("href", "#")
        if not body or len(body.strip()) < 30:
            continue

        sources.append({"id": idx, "title": title, "snippet": body[:250], "url": href})
        formatted_context.append(f"УЗЕЛ ДАННЫХ [{idx}]:\nЗаголовок: {title}\nФакты: {body}\nURL: {href}")

    return "\n\n".join(formatted_context), sources


def clean_duplicated_tail_citations(text: str) -> str:
    cleaned = re.sub(r'(\n|\s)*(Примечания|Источники|Ссылки|Литература)?(\s*\[\d+\][\s\S]*)$', '', text.strip(), flags=re.IGNORECASE)
    cleaned = re.sub(r'(\s*\[\d+\]\s*)+$', '', cleaned.strip())
    return cleaned


def format_interactive_markdown_sources(text: str, sources: list) -> str:
    if not sources:
        return text

    clean_text = clean_duplicated_tail_citations(text)

    def replace_citation(match):
        idx_str = match.group(1)
        try:
            idx = int(idx_str)
            src = next((s for s in sources if s["id"] == idx), None)
            if src:
                tooltip = f"{src['title']} — {src['snippet'][:180]}"
                return f' [[{idx}]]({src["url"]} "{tooltip}")'
        except Exception:
            pass
        return match.group(0)

    return re.sub(r'\[(\d+)\]', replace_citation, clean_text)


# ====================== ФАЙЛЫ ПРОЕКТА ======================
_KNOWN_TOOL_NAMES = (
    "explore_project_structure|run_pytest_suite|cyber_environment_doctor|"
    "validate_python_syntax|save_code_to_sandbox|recall_audit_memory|save_finding_to_memory"
)


def clean_code_output(raw_text: str) -> str:
    cleaned = raw_text.strip()
    if cleaned.startswith("{") and "report" in cleaned:
        try:
            parsed = json.loads(cleaned)
            rep = parsed.get("report", {})
            lines = [f"# {rep.get('title', 'Отчет безопасности')}\n"]
            for sec in rep.get("sections", []):
                lines.append(f"### {sec.get('section_title', '')}\n{sec.get('content', '')}\n")
            for issue in rep.get("security_issues", []):
                lines.append(f"- **{issue.get('issue')}**: {issue.get('description')} (`{issue.get('location')}`)")
            return "\n".join(lines)
        except Exception:
            pass

    cleaned = re.sub(r'```json\s*\{\s*"name":\s*".*?"\s*\}\s*```', '', cleaned, flags=re.DOTALL)
    cleaned = re.sub(r'\{\s*"name":\s*"(' + _KNOWN_TOOL_NAMES + r')".*?\}', '', cleaned, flags=re.DOTALL)
    return cleaned.strip()


def slugify_filename(text: str, default: str = "service", max_words: int = 5) -> str:
    """Превращает запрос пользователя в короткое латинское имя файла.
    Нужно, чтобы разные задачи (auth-сервис, сервис заказов, ...) не
    перезаписывали один и тот же auth_service.py, как это было раньше."""
    text = (text or "").lower()
    translit_map = str.maketrans({
        "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e", "ж": "zh",
        "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m", "н": "n", "о": "o",
        "п": "p", "р": "r", "с": "s", "т": "t", "у": "u", "ф": "f", "х": "h", "ц": "ts",
        "ч": "ch", "ш": "sh", "щ": "sch", "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya",
    })
    text = text.translate(translit_map)
    text = re.sub(r"[^a-z0-9]+", "_", text).strip("_")
    stop_words = {"sozdai", "sozday", "napishi", "razrabotay", "razrabotai", "novyy", "novyi",
                  "mikroservis", "servis", "the", "a", "an", "for", "please", "pozhaluysta"}
    words = [w for w in text.split("_") if w and w not in stop_words][:max_words]
    slug = "_".join(words) if words else default
    return slug[:40]


def force_save_code(content: str, default_filename: str = "service.py") -> str:
    try:
        code_to_save = content
        if "```python" in content:
            code_to_save = content.split("```python")[1].split("```")[0].strip()
        elif "```" in content:
            code_to_save = content.split("```")[1].split("```")[0].strip()

        code_to_save = clean_code_output(code_to_save)
        if not code_to_save:
            return ""
        file_path = os.path.join(WORKING_DIR, default_filename)
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(code_to_save)
        return file_path
    except Exception as e:
        print(f"\n[ERROR_DISK_WRITE] {e}")
        return ""


def detect_local_file_content(user_request: str) -> tuple[str, str]:
    """Если пользователь явно называет существующий файл — берём его.
    Иначе, вместо жёсткого fallback на auth_service.py (которого может
    и не быть), берём самый свежий .py файл в песочнице — так работает
    интуитивно понятнее с несколькими проектами в output/."""
    req = user_request.lower()
    candidates = []
    for root, _, files in os.walk(WORKING_DIR):
        for f in files:
            if not f.endswith(".py") or f.startswith("test_"):
                continue
            fpath = os.path.join(root, f)
            try:
                mtime = os.path.getmtime(fpath)
            except OSError:
                continue
            candidates.append((fpath, f, mtime))

    for fpath, f, _ in candidates:
        if f.lower() in req:
            try:
                with open(fpath, "r", encoding="utf-8", errors="ignore") as fp:
                    lines = fp.readlines()
                return f, "".join(lines[:150])
            except Exception:
                pass

    if candidates:
        candidates.sort(key=lambda x: x[2], reverse=True)
        fpath, f, _ = candidates[0]
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as fp:
                lines = fp.readlines()
            return f, "".join(lines[:150])
        except Exception:
            pass
    return "", ""


def git_commit_project(commit_message: str = "Автоматический коммит агента") -> str:
    """Версионирует output/ через git — история всех сгенерированных и
    пропатченных версий сервисов достаётся бесплатно, без своей БД версий.
    Вызывается детерминированно из оркестрации (не полагаемся на то,
    что маленькая модель сама вспомнит вызвать такой инструмент)."""
    try:
        if not os.path.exists(os.path.join(WORKING_DIR, ".git")):
            subprocess.run(["git", "init"], cwd=WORKING_DIR, capture_output=True, timeout=10)
            subprocess.run(["git", "config", "user.email", "agent@local"], cwd=WORKING_DIR, capture_output=True, timeout=5)
            subprocess.run(["git", "config", "user.name", "CyberAgent"], cwd=WORKING_DIR, capture_output=True, timeout=5)
        subprocess.run(["git", "add", "-A"], cwd=WORKING_DIR, capture_output=True, timeout=10)
        msg = (commit_message or "Автоматический коммит агента")[:200].replace('"', "'")
        proc = subprocess.run(
            ["git", "commit", "-m", msg], cwd=WORKING_DIR,
            capture_output=True, text=True, timeout=10
        )
        if proc.returncode == 0:
            return f"OK: {proc.stdout.strip()[:200]}"
        if "nothing to commit" in (proc.stdout + proc.stderr).lower():
            return "Нет изменений для коммита."
        return f"git commit код {proc.returncode}: {proc.stderr[:300]}"
    except FileNotFoundError:
        return "git не установлен — коммит пропущен."
    except Exception as e:
        return f"Ошибка git: {str(e)}"


# ====================== КИБЕР-СКИЛЛЫ АГЕНТОВ (CrewAI tools) ======================
def safe_path(file_path: str) -> str:
    base = os.path.abspath(WORKING_DIR)
    target = os.path.abspath(os.path.join(base, file_path))
    if not target.startswith(base):
        raise ValueError("ACCESS DENIED: Попытка выхода за пределы рабочей директории.")
    return target


@tool
def explore_project_structure(dummy: str = "") -> str:
    """Исследует файловую структуру каталога output/. Возвращает дерево всех файлов и их размеры."""
    try:
        tree = []
        base = os.path.abspath(WORKING_DIR)
        for root, dirs, files in os.walk(base):
            dirs[:] = [d for d in dirs if d != ".git"]
            level = root.replace(base, '').count(os.sep)
            indent = ' ' * 4 * level
            tree.append(f"{indent}📁 {os.path.basename(root)}/")
            subindent = ' ' * 4 * (level + 1)
            for f in sorted(files):
                fpath = os.path.join(root, f)
                size_kb = round(os.path.getsize(fpath) / 1024, 1)
                tree.append(f"{subindent}📄 {f} ({size_kb} KB)")
        if not tree:
            return "Папка проекта пуста."
        return "\n".join(tree)
    except Exception as e:
        return f"Ошибка сканирования дерева: {str(e)}"


@tool
def run_pytest_suite(test_file: str = "test_service.py") -> str:
    """Запускает набор тестов pytest в песочнице output/ и возвращает результат выполнения.
    Файл теста и файл сервиса, который он импортирует, должны уже быть сохранены на диск
    (через save_code_to_sandbox) — иначе тест не найдёт модуль для импорта."""
    try:
        target = safe_path(test_file)
        if not os.path.exists(target):
            return f"Ошибка: Файл тестов {test_file} не найден. Сначала сохрани его через save_code_to_sandbox."

        cmd = [sys.executable, "-m", "pytest", target, "-v", "--no-header", "-tb=short"]
        proc = subprocess.run(
            cmd,
            cwd=WORKING_DIR,
            capture_output=True,
            text=True,
            timeout=35
        )
        out = proc.stdout if proc.stdout else ""
        err = proc.stderr if proc.stderr else ""
        return f"[PYTEST RETURN CODE: {proc.returncode}]\n{out}\n{err}"
    except subprocess.TimeoutExpired:
        return "Ошибка: Тесты превысили лимит времени выполнения (35 сек)."
    except Exception as e:
        return f"Ошибка запуска тестов: {str(e)}"


@tool
def validate_python_syntax(file_path: str) -> str:
    """Быстро проверяет, что Python-файл в песочнице output/ синтаксически корректен
    (через py_compile, без реального запуска кода). Используй перед run_pytest_suite,
    чтобы сразу отличить синтаксическую ошибку от логической."""
    try:
        target = safe_path(file_path)
        if not os.path.exists(target):
            return f"Ошибка: файл {file_path} не найден. Сначала сохрани его через save_code_to_sandbox."
        proc = subprocess.run(
            [sys.executable, "-m", "py_compile", target],
            capture_output=True, text=True, timeout=10
        )
        if proc.returncode == 0:
            return f"OK: {file_path} — синтаксис корректен."
        return f"ОШИБКА СИНТАКСИСА в {file_path}:\n{proc.stderr[:1500]}"
    except subprocess.TimeoutExpired:
        return "Ошибка: проверка синтаксиса превысила лимит времени."
    except Exception as e:
        return f"Ошибка проверки синтаксиса: {str(e)}"


@tool
def save_code_to_sandbox(code: str, file_name: str) -> str:
    """Сохраняет Python-код в песочницу output/. Используй, чтобы записать
    промежуточную версию файла на диск перед проверкой через validate_python_syntax
    или run_pytest_suite — без этого те инструменты не увидят твой код."""
    try:
        path = force_save_code(code, file_name)
        return f"Сохранено: {path}" if path else "Не удалось сохранить файл (пустой код?)."
    except Exception as e:
        return f"Ошибка сохранения: {str(e)}"


@tool
def cyber_environment_doctor(check_type: str = "full") -> str:
    """Диагностирует окружение: проверяет порт 7860, доступность Ollama API и целостность базы данных."""
    report = []
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        port_in_use = s.connect_ex(('127.0.0.1', 7860)) == 0
        report.append(f"🔌 Порт 7860 (Gradio): {'Занят (активен)' if port_in_use else 'Свободен'}")

    try:
        req = urllib.request.Request(f"{OLLAMA_HOST}/api/tags")
        with urllib.request.urlopen(req, timeout=2) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            models_count = len(data.get("models", []))
            report.append(f"🟢 Ollama API: Доступен (Моделей найдено: {models_count})")
    except Exception:
        report.append("🔴 Ollama API: Ошибка подключения (сервер не отвечает)")

    db_exists = os.path.exists(DB_PATH)
    output_exists = os.path.exists(WORKING_DIR)
    report.append(f"💾 База данных (chats.db): {'Найдена' if db_exists else 'Отсутствует'}")
    report.append(f"📁 Папка песочницы (output/): {'Готова' if output_exists else 'Создается'}")

    return "\n".join(report)


@tool
def recall_audit_memory(topic: str) -> str:
    """Ищет в базе прошлых аудитов безопасности (agent_notes) записи,
    семантически близкие к теме — через эмбеддинги nomic-embed-text."""
    notes = recall_relevant_notes(topic, top_k=3)
    if not notes:
        return "Релевантных прошлых заметок не найдено."
    lines = []
    for n in notes:
        lines.append(f"[{n['date']}] (сходство {n['score']}) {n['title']}:\n{n['content'][:400]}")
    return "\n\n".join(lines)


@tool
def save_finding_to_memory(title: str, content: str) -> str:
    """Сохраняет важную находку (уязвимость, паттерн, решение) в долговременную
    память агентов с векторным индексом для последующего поиска через recall_audit_memory."""
    try:
        save_note_with_embedding(title, content, tags="agent_finding")
        return "Заметка сохранена в базу знаний."
    except Exception as e:
        return f"Ошибка сохранения заметки: {str(e)}"


# Наборы инструментов по ролям. Раньше все агенты получали один и тот же
# список из 3 инструментов — с маленькими локальными моделями (7-8B)
# каждый лишний инструмент в схеме немного снижает надёжность
# tool-calling, поэтому даём только то, что реально нужно роли.
TOOLS_ARCHITECT = [explore_project_structure, recall_audit_memory, cyber_environment_doctor]
TOOLS_CODER = [explore_project_structure, save_code_to_sandbox, validate_python_syntax]
TOOLS_SECURITY = [explore_project_structure, recall_audit_memory, save_finding_to_memory]
TOOLS_PATCH = [save_code_to_sandbox, validate_python_syntax, run_pytest_suite]
TOOLS_QA = [save_code_to_sandbox, validate_python_syntax, run_pytest_suite]
TOOLS_RESEARCH = [explore_project_structure, cyber_environment_doctor]


# ====================== ВНЕШНИЙ ПРОЦЕСС CREWAI ======================
def worker_crew_execution(mode, user_request, raw_web_context, target_filename, target_file_code,
                           general_m, coder_m, cyber_m, patch_m, qa_m, result_queue, log_queue):
    sys.stdout = QueueStreamLogger(log_queue)
    try:
        llm_general = LLM(model=f"ollama/{general_m}", base_url=OLLAMA_HOST, temperature=0.2, max_tokens=3000, timeout=300)
        llm_coder = LLM(model=f"ollama/{coder_m}", base_url=OLLAMA_HOST, temperature=0.1, max_tokens=4096, timeout=300)
        llm_cyber = LLM(model=f"ollama/{cyber_m}", base_url=OLLAMA_HOST, temperature=0.1, max_tokens=2500, timeout=300)
        llm_patch = LLM(model=f"ollama/{patch_m}", base_url=OLLAMA_HOST, temperature=0.1, max_tokens=4096, timeout=300)
        llm_qa = LLM(model=f"ollama/{qa_m}", base_url=OLLAMA_HOST, temperature=0.1, max_tokens=3500, timeout=300)

        # Имя файла теперь не жёстко "auth_service.py": если правим существующий
        # файл — берём его имя, иначе генерируем короткий slug из запроса,
        # чтобы разные задачи не затирали друг друга на диске.
        service_filename = target_filename or f"{slugify_filename(user_request)}.py"
        test_filename = f"test_{service_filename}" if not service_filename.startswith("test_") else service_filename

        def _save_service_cb(task_output):
            try:
                force_save_code(str(task_output.raw), service_filename)
            except Exception:
                pass

        def _save_test_cb(task_output):
            try:
                force_save_code(str(task_output.raw), test_filename)
            except Exception:
                pass

        if mode == "test_gen":
            qa_engineer = Agent(
                role="Senior QA Security Test Engineer",
                goal="Написание автономных тестов pytest с TestClient",
                backstory="Ведущий QA-инженер по безопасности API.",
                llm=llm_qa,
                tools=TOOLS_QA,
                max_iter=8,
                handle_parsing_errors=True,
                verbose=True
            )
            t = Task(
                description=(
                    f"ЗАДАЧА: Напиши изолированный файл тестов pytest для файла `{target_filename or service_filename}`.\n\n"
                    f"РЕАЛЬНЫЙ КОД СЕРВИСА НА ДИСКЕ:\n```python\n{target_file_code}\n```\n\n"
                    "ОБЯЗАТЕЛЬНЫЕ ПРАВИЛА:\n"
                    "1. Импортируй: `from " + service_filename.replace(".py", "") + " import app`, `from fastapi.testclient import TestClient`.\n"
                    "2. Создай: `client = TestClient(app)`.\n"
                    "3. Напиши позитивные и негативные кейсы (ошибки 401, 400, 403).\n"
                    "4. СТРОГИЙ ЗАПРЕТ: Не пиши код самого сервиса в тестах. Только тесты в одном блоке ```python ... ```.\n"
                    f"5. Когда код теста готов, сохрани его через save_code_to_sandbox с file_name='{test_filename}', "
                    "затем проверь через validate_python_syntax."
                ),
                expected_output="Python-код файла тестов pytest в блоке ```python```.",
                agent=qa_engineer,
                callback=_save_test_cb,
            )
            crew = Crew(agents=[qa_engineer], tasks=[t], process=Process.sequential, verbose=True)
            res = crew.kickoff()
            result_queue.put({"status": "ok", "tests": str(res), "raw": str(res),
                               "service_filename": service_filename, "test_filename": test_filename})

        elif mode == "full_dev":
            recall_notes = recall_relevant_notes(user_request, top_k=3)
            recall_block = format_recall_block(recall_notes)

            architect = Agent(
                role="System Architect",
                goal="Архитектура микросервисов с глубоким исследованием",
                backstory="Кибер-архитектор систем. Следуй принципам Research-инженерии: опирайся на точные факты, проектируй надежные схемы без домыслов.",
                llm=llm_general,
                tools=TOOLS_ARCHITECT,
                verbose=True
            )
            coder = Agent(
                role="Senior Backend Developer",
                goal="Написание начального кода",
                backstory="Senior Python разработчик.",
                llm=llm_coder,
                tools=TOOLS_CODER,
                max_iter=10,
                handle_parsing_errors=True,
                verbose=True
            )
            security_expert = Agent(
                role="Cybersecurity Specialist",
                goal="Строгий аудит кода по стандарту Code Review (Standards & Spec)",
                backstory="Ведущий AppSec-аудитор. Проводишь двухосевую оценку: проверяешь код на соответствие спецификации (Spec) и стандартам безопасности (Standards). Отвечай строго в формате Markdown, без сырого JSON.",
                llm=llm_cyber,
                tools=TOOLS_SECURITY,
                max_iter=8,
                handle_parsing_errors=True,
                verbose=True
            )
            patch_engineer = Agent(
                role="Patch & Remediation Engineer",
                goal="Устранение уязвимостей в коде",
                backstory="Инженер по безопасности и патчингу. Исправляешь замечания аудитора, применяя безопасные практики.",
                llm=llm_patch,
                tools=TOOLS_PATCH,
                max_iter=10,
                handle_parsing_errors=True,
                verbose=True
            )
            qa_engineer = Agent(
                role="QA Test Automation Engineer",
                goal="Написание тестов pytest",
                backstory="Эксперт тестирования API.",
                llm=llm_qa,
                tools=TOOLS_QA,
                max_iter=8,
                handle_parsing_errors=True,
                verbose=True
            )

            t1 = Task(description=f"{recall_block}Спроектируй микросервис: {user_request}.", expected_output="План архитектуры.", agent=architect)
            t2 = Task(
                description=f"Напиши полный код на FastAPI с SQLite и SQLAlchemy. Без сокращений. "
                            f"После генерации сохрани файл через save_code_to_sandbox с file_name='{service_filename}'.",
                expected_output="Python-код сервиса в блоке ```python```.", agent=coder, context=[t1],
                callback=_save_service_cb,
            )
            t3 = Task(
                description=f"{recall_block}Проведи аудит безопасности полученного кода. Выяви уязвимости, CWE, OWASP. Строго без JSON! "
                            f"Файл сервиса уже сохранён на диске как '{service_filename}' — можешь исследовать его через explore_project_structure.",
                expected_output="Отчет безопасности в Markdown.", agent=security_expert, context=[t2],
            )
            t4 = Task(
                description=f"На основе отчета безопасности исправь весь уязвимый код в файле '{service_filename}', "
                            "примени безопасные практики. Сохрани исправленный код через save_code_to_sandbox "
                            f"с тем же file_name='{service_filename}', затем проверь его через validate_python_syntax. "
                            "Выдай итоговый безопасный код в блоке ```python```.",
                expected_output="Исправленный безопасный Python-код в блоке ```python```.", agent=patch_engineer, context=[t2, t3],
                callback=_save_service_cb,
            )
            t5 = Task(
                description=f"Напиши автономный набор тестов pytest для финального безопасного кода сервиса "
                            f"(файл '{service_filename}', импортируй `from {service_filename[:-3]} import app`). "
                            f"Сохрани тест через save_code_to_sandbox с file_name='{test_filename}' и прогони через run_pytest_suite.",
                expected_output="Python-код файла тестов pytest.", agent=qa_engineer, context=[t4],
                callback=_save_test_cb,
            )

            crew = Crew(agents=[architect, coder, security_expert, patch_engineer, qa_engineer], tasks=[t1, t2, t3, t4, t5], process=Process.sequential, verbose=True)
            res = crew.kickoff()

            code_out = str(t4.output.raw) if hasattr(t4, 'output') and t4.output else (str(t2.output.raw) if hasattr(t2, 'output') and t2.output else "")
            sec_out = str(t3.output.raw) if hasattr(t3, 'output') and t3.output else ""
            test_out = str(t5.output.raw) if hasattr(t5, 'output') and t5.output else str(res)

            if sec_out:
                save_note_with_embedding(f"Аудит {service_filename}", sec_out[:1500], "security_audit")

            result_queue.put({
                "status": "ok", "code": code_out, "sec": sec_out, "tests": test_out, "raw": str(res),
                "service_filename": service_filename, "test_filename": test_filename,
            })

        elif mode == "sec_only":
            recall_notes = recall_relevant_notes(user_request, top_k=3)
            recall_block = format_recall_block(recall_notes)

            security_expert = Agent(
                role="Senior Application Security Engineer",
                goal="Глубокий аудит безопасности исходного кода",
                backstory="Ведущий AppSec-аудитор. СТРОГИЙ ЗАПРЕТ НА JSON! Выдавай ответ исключительно в читаемом формате Markdown на русском языке.",
                llm=llm_cyber,
                tools=TOOLS_SECURITY,
                max_iter=8,
                handle_parsing_errors=True,
                verbose=True
            )
            file_context_prompt = f"РЕАЛЬНОЕ СОДЕРЖИМОЕ ФАЙЛА НА ДИСКЕ ({target_filename}):\n```python\n{target_file_code}\n```\n\n" if target_file_code else ""
            t = Task(
                description=(
                    f"{recall_block}ЗАДАЧА: Проведи глубокий аудит безопасности кода по запросу: {user_request}\n\n"
                    f"{file_context_prompt}"
                    "ПРАВИЛА:\n1. Запрещено использовать JSON. Пиши отчет обычным текстом с заголовками Markdown.\n"
                    "2. Выяви уязвимости, CWE, OWASP и дай рекомендации по исправлению."
                ),
                expected_output="Отчет по аудиту безопасности в формате Markdown.",
                agent=security_expert
            )
            crew = Crew(agents=[security_expert], tasks=[t], process=Process.sequential, verbose=True)
            res = crew.kickoff()
            save_note_with_embedding(f"Аудит {target_filename or user_request[:60]}", str(res)[:1500], "security_audit")
            result_queue.put({"status": "ok", "raw": str(res)})

        elif mode == "code_only":
            coder = Agent(role="Senior Backend Developer", goal="Писать чистый код", backstory="Senior разработчик.", llm=llm_coder, tools=TOOLS_CODER, max_iter=10, handle_parsing_errors=True, verbose=True)
            t = Task(
                description=f"Напиши рабочий код: {user_request}. В блоке ```python ... ```. "
                             f"Сохрани через save_code_to_sandbox с file_name='{service_filename}'.",
                expected_output="Рабочий код.", agent=coder, callback=_save_service_cb,
            )
            crew = Crew(agents=[coder], tasks=[t], process=Process.sequential, verbose=True)
            res = crew.kickoff()
            result_queue.put({"status": "ok", "raw": str(res), "service_filename": service_filename})

        else:
            researcher = Agent(role="Senior Research Analyst", goal="Анализ источников", backstory="Кибер-аналитик данных.", llm=llm_general, tools=TOOLS_RESEARCH, verbose=True)
            t = Task(
                description=f"ЗАДАЧА: Подготовь подробный отчет по теме: {user_request}\n\n{raw_web_context}",
                expected_output="Отчет со сносками.",
                agent=researcher
            )
            crew = Crew(agents=[researcher], tasks=[t], process=Process.sequential, verbose=True)
            res = crew.kickoff()
            result_queue.put({"status": "ok", "raw": str(res)})

    except Exception as e:
        import traceback
        result_queue.put({"status": "error", "error": str(e), "trace": traceback.format_exc()})
